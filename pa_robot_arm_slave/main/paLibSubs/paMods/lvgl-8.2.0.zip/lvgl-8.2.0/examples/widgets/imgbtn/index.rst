
Simple Image button 
"""""""""""""""""""

.. lv_example:: widgets/imgbtn/lv_example_imgbtn_1
  :language: c

